
import React, { createContext, useState, useContext, ReactNode, useEffect } from 'react';
import { Hotel, Room, Booking } from '../types';
import { BOOKINGS } from '../constants';

interface BookingDetails {
    hotel: Hotel | null;
    room: Room | null;
    checkInDate: string;
    checkOutDate: string;
    totalPrice: number;
}

interface BookingContextType {
    bookings: Booking[];
    bookingDetails: BookingDetails;
    setBookingDetails: React.Dispatch<React.SetStateAction<BookingDetails>>;
    addBooking: (booking: Omit<Booking, 'id' | 'status'>, type?: 'customer' | 'agent-assigned') => Booking;
    updateBooking: (updatedBooking: Booking) => void;
    updateBookingStatus: (bookingId: string, status: Booking['status']) => void;
    deleteBookings: (bookingIds: string[]) => void;
    isBookingModalOpen: boolean;
    openBookingModal: (hotel: Hotel, room: Room) => void;
    closeBookingModal: () => void;
    requestCancellation: (bookingId: string) => void;
    requestDateChange: (bookingId: string, newCheckIn: string, newCheckOut: string, newTotalPrice: number) => void;
    approveChangeRequest: (bookingId: string) => void;
    rejectChangeRequest: (bookingId: string) => void;
}

const defaultBookingState: BookingDetails = {
    hotel: null,
    room: null,
    checkInDate: '',
    checkOutDate: '',
    totalPrice: 0,
};

const BookingContext = createContext<BookingContextType | undefined>(undefined);

export const BookingProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    // Load bookings from localStorage or fallback to default constants
    const [bookings, setBookings] = useState<Booking[]>(() => {
        const saved = localStorage.getItem('umrah_bookings');
        return saved ? JSON.parse(saved) : BOOKINGS;
    });

    const [bookingDetails, setBookingDetails] = useState<BookingDetails>(defaultBookingState);
    const [isBookingModalOpen, setBookingModalOpen] = useState(false);

    // Save bookings to localStorage whenever they change
    useEffect(() => {
        localStorage.setItem('umrah_bookings', JSON.stringify(bookings));
    }, [bookings]);

    const openBookingModal = (hotel: Hotel, room: Room) => {
        const today = new Date().toISOString().split('T')[0];
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        const tomorrowStr = tomorrow.toISOString().split('T')[0];
        
        setBookingDetails({ hotel, room, checkInDate: today, checkOutDate: tomorrowStr, totalPrice: room.customerPricePerNight });
        setBookingModalOpen(true);
    };

    const closeBookingModal = () => {
        setBookingDetails(defaultBookingState);
        setBookingModalOpen(false);
    };

    const addBooking = (bookingData: Omit<Booking, 'id' | 'status'>, type: 'customer' | 'agent-assigned' = 'customer'): Booking => {
        const newBooking: Booking = {
            ...bookingData,
            id: `BK${Math.floor(Math.random() * 90000) + 10000}`,
            status: type === 'agent-assigned' ? 'Confirmed' : 'Pending',
            bookingType: type,
        };
        setBookings(prev => [newBooking, ...prev]);
        return newBooking;
    };
    
    const updateBooking = (updatedBooking: Booking) => {
        setBookings(prev =>
            prev.map(booking =>
                booking.id === updatedBooking.id ? updatedBooking : booking
            )
        );
    };

    const updateBookingStatus = (bookingId: string, status: Booking['status']) => {
        setBookings(prev => 
            prev.map(booking => 
                booking.id === bookingId ? { ...booking, status } : booking
            )
        );
    };

    const deleteBookings = (bookingIds: string[]) => {
        setBookings(prev => prev.filter(booking => !bookingIds.includes(booking.id)));
    };

    const requestCancellation = (bookingId: string) => {
        setBookings(prev => prev.map(b => b.id === bookingId ? { ...b, status: 'Cancellation Requested' } : b));
    };

    const requestDateChange = (bookingId: string, newCheckIn: string, newCheckOut: string, newTotalPrice: number) => {
        setBookings(prev => prev.map(b => b.id === bookingId ? {
            ...b,
            status: 'Date Change Requested',
            requestedCheckInDate: newCheckIn,
            requestedCheckOutDate: newCheckOut,
        } : b));
    };
    
    const approveChangeRequest = (bookingId: string) => {
        setBookings(prev => prev.map(b => {
            if (b.id === bookingId) {
                if (b.status === 'Date Change Requested' && b.requestedCheckInDate && b.requestedCheckOutDate) {
                    const nights = (new Date(b.requestedCheckOutDate).getTime() - new Date(b.requestedCheckInDate).getTime()) / (1000 * 3600 * 24);
                    const oldNights = (new Date(b.checkOutDate).getTime() - new Date(b.checkInDate).getTime()) / (1000 * 3600 * 24);
                    const pricePerNight = oldNights > 0 ? b.totalPrice / oldNights : b.room.customerPricePerNight;
                    const newPrice = nights * pricePerNight;
                    
                    return { ...b, status: 'Confirmed', checkInDate: b.requestedCheckInDate, checkOutDate: b.requestedCheckOutDate, totalPrice: newPrice, requestedCheckInDate: undefined, requestedCheckOutDate: undefined };
                }
                if (b.status === 'Cancellation Requested') {
                    return { ...b, status: 'Cancelled' };
                }
            }
            return b;
        }));
    };
    
    const rejectChangeRequest = (bookingId: string) => {
        setBookings(prev => prev.map(b => {
            if (b.id === bookingId && (b.status === 'Date Change Requested' || b.status === 'Cancellation Requested')) {
                return { ...b, status: 'Confirmed', requestedCheckInDate: undefined, requestedCheckOutDate: undefined };
            }
            return b;
        }));
    };


    return (
        <BookingContext.Provider value={{
            bookings,
            bookingDetails,
            setBookingDetails,
            addBooking,
            updateBooking,
            updateBookingStatus,
            deleteBookings,
            isBookingModalOpen,
            openBookingModal,
            closeBookingModal,
            requestCancellation,
            requestDateChange,
            approveChangeRequest,
            rejectChangeRequest
        }}>
            {children}
        </BookingContext.Provider>
    );
};

export const useBooking = (): BookingContextType => {
    const context = useContext(BookingContext);
    if (context === undefined) {
        throw new Error('useBooking must be used within a BookingProvider');
    }
    return context;
};
